import axios from "axios";
import dotenv from 'dotenv-flow';
dotenv.config();

const axiosBack = axios.create({
    baseURL: process.env.BACK_END_URL,
    timeout: 500,
    headers: {
        'Authorization': process.env.INTRA_TOKEN,
    }
});

axiosBack.defaults.headers.post['Content-Type'] = 'application/json';

export {axiosBack};
