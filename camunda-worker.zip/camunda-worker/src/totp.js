import {TOTP} from '@otplib/core';
import {createDigest} from '@otplib/plugin-crypto';

const tokenGenerator = new TOTP({
    createDigest,
    digits: 6,
    window: [0, 10],
    algorithm: 'sha1',
    encoding: 'ascii',
    step: 10,
});


export {tokenGenerator};
