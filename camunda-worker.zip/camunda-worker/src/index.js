import dotenv from 'dotenv-flow';
import camunda from 'camunda-external-task-client-js';
import * as uuid from 'uuid';
import { axiosBack } from './axios';
import axios from 'axios';
import { URL } from 'url';
import { tokenGenerator } from './totp';

const {
    Client,
    logger,
    Variables
} = camunda;

dotenv.config();

const config = {
    baseUrl: process.env.CAMUNDA_ENGINE_URL,
    use: logger
};
const client = new Client(config);
console.log('camunda url:', process.env.CAMUNDA_ENGINE_URL);

const updateNotification = (requestId, doorLockId, cameraLocationId, profileId, eventId, probability, statusId, error, hasMask, maskProbability, accessDenied = false) => {
    return axiosBack.post(`/door-notification/show`, {
        id: requestId,
        doorId: doorLockId,
        locationId: cameraLocationId,
        profileId,
        eventId,
        probability,
        recognized: statusId === 1,
        accessDenied,
        error: error,
        maskType: hasMask ? 3 : 0,
        maskProbability,
    });
};

client.subscribe('SEND_ALARM', async ({
    task,
    taskService
}) => {
    console.log('SEND_ALARM');
    try {
        const type = task.variables.get('type');
        console.log('type:', type);

        await taskService.complete(task);
    } catch (e) {
        console.log(e);
    }
});

client.subscribe('OPEN_DOOR_REQUEST', async ({
    task,
    taskService
}) => {
    const profileId = task.variables.get('profileId');
    const doorLockId = task.variables.get('doorLockId');
    const cameraLocationId = task.variables.get('cameraLocationId');
    const statusId = task.variables.get('statusId');
    const maskProbability = task.variables.get('maskProbability');
    const hasMask = task.variables.get('hasMask');
    const eventId = task.variables.get('eventId');
    const probability = task.variables.get('probability');
    const error = task.variables.get('error');

    let requestId = task.variables.get('OPEN_DOOR_REQUEST_ID');
    const processVariables = new Variables();

    const values = task.variables.getAll();
    console.log(values);

    if (requestId === undefined || requestId === null) {
        requestId = uuid.v4();
        processVariables.set('OPEN_DOOR_REQUEST_ID', requestId);
    }

    if ((error !== undefined && error !== null) || statusId !== 1) {
        processVariables.set('canOpenDoor', false);
    } else {
        processVariables.set('canOpenDoor', true);
    }

    console.log('OPEN_DOOR_REQUEST', Date.now());
    console.log('requestId: ', requestId);

    try {
        await updateNotification(requestId, doorLockId, cameraLocationId, profileId, eventId, probability, statusId, error, hasMask, maskProbability);
    } catch (e) {
        console.log(e.message);
    }

    await taskService.complete(task, processVariables);
});

client.subscribe('CLOSE_DOOR_REQUEST', async ({
    task,
    taskService
}) => {
    const requestId = task.variables.get('OPEN_DOOR_REQUEST_ID');
    const doorLockId = task.variables.get('doorLockId');
    const cameraLocationId = task.variables.get('cameraLocationId');

    if (requestId === undefined || requestId === null) {
        console.log('CLOSE_DOOR_REQUEST requestId empty: ', requestId);
        await taskService.complete(task);
        return;
    }

    console.log('CLOSE_DOOR_REQUEST', Date.now());
    let processVariables = null;
    const values = task.variables.getAll();
    console.log(values);

    try {
        await axiosBack.post(`/door-notification/close`, {
            id: requestId,
            doorId: doorLockId,
            locationId: cameraLocationId,
        });
        processVariables = new Variables();
        processVariables.set('OPEN_DOOR_REQUEST_ID', undefined);
        processVariables.set('canOpenDoor', undefined);
    } catch (e) {
        console.log(e.message);
    }

    processVariables === null ? await taskService.complete(task) : await taskService.complete(task, processVariables);
});

client.subscribe('OPEN_DOOR', async ({
    task,
    taskService
}) => {
    const requestId = task.variables.get('OPEN_DOOR_REQUEST_ID');
    const statusId = task.variables.get('statusId');
    const doorLockUrl = task.variables.get('doorLockUrl');
    const doorLockToken = task.variables.get('doorLockToken');
    const doorLockId = task.variables.get('doorLockId');
    const cameraLocationId = task.variables.get('cameraLocationId');
    const profileId = task.variables.get('profileId');
    const maskProbability = task.variables.get('maskProbability');
    const hasMask = task.variables.get('hasMask');
    const eventId = task.variables.get('eventId');
    const probability = task.variables.get('probability');

    const values = task.variables.getAll();
    console.log(values);

    console.log('OPEN_DOOR', Date.now());

    try {
        const lockUrl = new URL(doorLockUrl);
        const token = tokenGenerator.generate(doorLockToken);

        await axios.post(lockUrl.toString(), {
            token,
        }, {
            timeout: 5000
        });
        await axiosBack.post(`/door-notification/opened`, {
            id: requestId,
            doorId: doorLockId,
            locationId: cameraLocationId,
        });
    } catch (e) {
        if (e.response) {
            const { status } = e.response;

            switch (status) {
            case 403:
                await updateNotification(requestId, doorLockId, cameraLocationId, profileId, eventId, probability, statusId, 'Door access denied', hasMask, maskProbability);
                break;
            case 500:
                await updateNotification(requestId, doorLockId, cameraLocationId, profileId, eventId, probability, statusId, 'Server error', hasMask, maskProbability);
                break;

            default:
                await updateNotification(requestId, doorLockId, cameraLocationId, profileId, eventId, probability, statusId, "Error", hasMask, maskProbability);
                break;

            }
        } else {
            await updateNotification(requestId, doorLockId, cameraLocationId, profileId, eventId, probability, statusId, "Timeout", hasMask, maskProbability);
        }
        console.log(e.message);
    }

    await taskService.complete(task);
});

client.subscribe('SET_IS_OPEN_TRUE', async ({
    task,
    taskService
}) => {
    console.log('SET_IS_OPEN_TRUE', Date.now());
    const processVariables = new Variables();
    const values = task.variables.getAll();
    console.log(values);
    processVariables.set('isSubmitted', true);

    await taskService.complete(task, processVariables);
});

client.subscribe('RESET_VARIABLES_AFTER_OPEN', async ({
    task,
    taskService
}) => {
    console.log('RESET_VARIABLES_AFTER_OPEN', Date.now());
    const values = task.variables.getAll();
    console.log(values);


    const isSubmitted = task.variables.get('isSubmitted');
    let processVariables = null;

    if (isSubmitted !== true) {
        processVariables = new Variables();
        processVariables.set('isOpenDoor', undefined);
        processVariables.set('openedByGuard', undefined);
    }

    processVariables === null ? await taskService.complete(task) : await taskService.complete(task, processVariables);
});

client.subscribe('SET_IS_OPEN_FALSE', async ({
    task,
    taskService
}) => {
    console.log('SET_IS_OPEN_FALSE', Date.now());

    const values = task.variables.getAll();
    console.log(values);

    const processVariables = new Variables();
    processVariables.set('isOpenDoor', undefined);
    processVariables.set('isSubmitted', undefined);
    processVariables.set('openedByGuard', undefined);

    await taskService.complete(task, processVariables);
});

client.subscribe('CALL_TO', async ({
    task,
    taskService
}) => {
    const values = task.variables.getAll();
    console.log(values);

    const id = task.variables.get('CALL_ID');
    const info = task.variables.get('CALL_INFO');
    const caller = task.variables.get('CALLER');
    const profiles = task.variables.get('profiles');
    const groups = task.variables.get('groups');

    const participants = [];

    if (profiles) {
        participants.push({
            type: 'profiles',
            value: JSON.parse(profiles),
        })
    }

    if (groups) {
        participants.push({
            type: 'groups',
            value: JSON.parse(groups),
        })
    }
    try {
        await axiosBack.post(`/calls/call`, {
            id,
            info,
            caller,
            participants,
        });
    } catch (err) {
        console.log(err);
    }

    await taskService.complete(task);
});

client.subscribe('END_CALL', async ({
    task,
    taskService
}) => {
    const values = task.variables.getAll();
    console.log(values);

    const id = task.variables.get('CALL_ID');
    const caller = task.variables.get('CALLER');
    const error = task.variables.get('error');

    try {
        await axiosBack.post(`/calls/end`, {
            id,
            caller,
            error,
        });
    } catch (err) {
        console.log(err);
    }
    await taskService.complete(task);
});
